public class trim {
    public static void main(String[] args) {

        String username = "   admin   ";

        System.out.println("Sebelum trim: [" + username + "]");

        username = username.trim();

        System.out.println("Sesudah trim: [" + username + "]");
    }
}

