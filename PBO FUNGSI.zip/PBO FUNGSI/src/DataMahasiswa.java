public class DataMahasiswa {
    public static void main(String[] args) {

        // Data mentah dari sistem
        String data = " 2025001,Dede_Suryana,Teknik Informatika ";

        // 1. trim()
        data = data.trim();
 
        // 2. split()
        String[] hasil = data.split(",");

        String nim = hasil[0];
        String nama = hasil[1];
        String prodi = hasil[2];

        // 3. replace()
        nama = nama.replace("_", " ");

        // 4. substring()
        String angkatan = nim.substring(0, 4);

        // 5. repeat()
        String garis = "=".repeat(40);

        // 6. concat()
        String info = "Mahasiswa ".concat(nama);

        // Output
        System.out.println(garis);
        System.out.println("DATA MAHASISWA");
        System.out.println(garis);

        System.out.println(info);
        System.out.println("NIM       : " + nim);
        System.out.println("Angkatan  : " + angkatan);
        System.out.println("Prodi     : " + prodi);

        System.out.println(garis);
    }
}