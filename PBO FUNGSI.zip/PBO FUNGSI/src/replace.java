public class replace {
    public static void main(String[] args) {

        String kalimat = "Saya belajar PHP";

        String hasil = kalimat.replace("PHP", "Java");

        System.out.println(hasil);
    }
}
