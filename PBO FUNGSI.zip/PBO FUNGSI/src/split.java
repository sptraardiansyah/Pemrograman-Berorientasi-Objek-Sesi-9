public class split {
    public static void main(String[] args) {

        String matkul = "Java,Database,Jaringan";

        String[] data = matkul.split(",");

        System.out.println("Mata Kuliah 1: " + data[0]);
        System.out.println("Mata Kuliah 2: " + data[1]);
        System.out.println("Mata Kuliah 3: " + data[2]);
    }
}

