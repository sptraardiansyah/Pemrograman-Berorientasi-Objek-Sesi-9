public class sensorKata
 {
    public static void main(String[] args) {
        String kalimatAsli = "Saya benci Kamu";
        String kataDisensor = "benci";

        int panjangKata = kataDisensor.length();

        String tandaSensor = "=" .repeat(panjangKata);

        String kalimatHasil = kalimatAsli.replace(kataDisensor, tandaSensor);

        System.out.println("Kalimat Asli : " + kalimatAsli);
        System.out.println("Kalimat Hasil : " + kalimatHasil);
        
    }
}

