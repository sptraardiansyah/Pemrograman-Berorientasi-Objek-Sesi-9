public class concat {
    public static void main(String[] args) {

        String namaDepan = "Suryana";
        String namaBelakang = "Dede";

        String namaLengkap = namaDepan.concat(" ").concat(namaBelakang);

        System.out.println("Nama Lengkap: " + namaLengkap);
    }
}