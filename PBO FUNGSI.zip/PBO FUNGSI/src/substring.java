public class substring {
    public static void main(String[] args) {

        String tanggal = "19-05-2026";

        String tahun = tanggal.substring(6);

        System.out.println("Tahun: " + tahun);
    }
}


